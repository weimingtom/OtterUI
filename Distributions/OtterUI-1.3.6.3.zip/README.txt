	
	OtterUI v. 1.3.6.3
	
Welcome!  This package includes everything you will need to start creating exciting User Interfaces
with OtterUI.

Contents:
---------

/API			:	Precompiled libraries and header files
/Editor			:	OtterUI Editor
/SampleApp		:	Sample Applications and plugin

Getting Started:
----------------

(1)  The Otter UI Editor is used to layout and animate your User Interface.  The Installation file is located at:

/Editor/setup.exe

Run this file and follow the instructions.

(2)  The online Help Documentation contains useful information such as setup/installation steps, tutorials, and 
introduction of the Sample App. The help documents are located at: 

http://www.twolewis.com/otterui/help-1.3.6.3

(3)  Several Sample Applications are provided in this package for PC, iOS, Android, and Unity (PC, Mac, and iOS).  See
the Help Documentation for details on setup and installation.  A precompiled Windows SampleApp is found at:

--------------------------------------------------------------------
Thank you for trying OtterUI, by Aonyx Software. 
If you have any questions or feedback, please contact us at 
info@otterui.com, or visit us at http://www.otterui.com
--------------------------------------------------------------------