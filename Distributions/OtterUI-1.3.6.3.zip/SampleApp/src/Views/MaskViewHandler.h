//
// Copyright (c) Lloyd Tullues
// All rights reserved.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND 
// CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, 
// INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, 
// OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
// OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
// OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#pragma once
#include "ViewHandler.h"

/* Handles the events from the mask view
 */
class MaskViewHandler : public ViewHandler
{
public:

	/* Constructor
	 */
	MaskViewHandler(SampleUI* pSampleUI, View* pView);

	/* Virtual Destructor
	 */
	virtual ~MaskViewHandler(void);

private:

	/** @brief Executed when the view has become active
	 */
	void	OnActivate(void* pSender, void* pContext);

	/** @brief Executed when the view has become deactive
	 */
	void	OnDeactivate(void* pSender, void* pContext);

	/** @brief Executed when an animation has completed
	 */
	void	OnAnimationEnded(void* pSender, uint32 animID);

	/* Called when the Next Button has been clicked
	 */
	void	OnNextButtonClicked(void* pSender, void* pData);

	/* Called when the Prev Button has been clicked
	 */
	void	OnPrevButtonClicked(void* pSender, void* pData);

private:

	Button*						mNextButton;
	Button*						mPrevButton;
};
