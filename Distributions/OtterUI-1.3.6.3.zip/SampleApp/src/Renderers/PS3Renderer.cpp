#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/timer.h>
#include <sys/return_code.h>
#include <sys/process.h>
#include <cell/gcm.h>
#include <cell/sysmodule.h>
#include <stddef.h>
#include <math.h>
#include <sysutil/sysutil_sysparam.h>
#include <cell/codec/pngdec.h>

#include "PS3Renderer.h"

#define NUM_VERTS		4000
#define NUM_INDICES		NUM_VERTS
#define BASED_ALIGN		128

bool decodePng(const char* szPath, CellGcmTexture& tex);

using namespace cell::Gcm;

static Otter::GUIVertex *vertex_buffer = NULL;

/* local memory allocation */
static uint32_t local_mem_heap = 0;
static void *localMemoryAlloc(const uint32_t size) 
{
	uint32_t allocated_size = (size + 1023) & (~1023);
	uint32_t base = local_mem_heap;
	local_mem_heap += allocated_size;
	return (void*)base;
}

static void *localMemoryAlign(const uint32_t alignment, 
		const uint32_t size)
{
	local_mem_heap = (local_mem_heap + alignment-1) & (~(alignment-1));
	return (void*)localMemoryAlloc(size);
}

/* double buffering */
#define COLOR_BUFFER_NUM 2

/* prototypes */

static void setRenderState(void);
static void setDrawEnv(void);

uint32_t display_width;
uint32_t display_height; 

float    display_aspect_ratio;
uint32_t color_pitch;
uint32_t depth_pitch;
uint32_t color_offset[COLOR_BUFFER_NUM];
uint32_t depth_offset;

extern uint32_t _binary_vpshader_vpo_start;
extern uint32_t _binary_vpshader_vpo_end;
extern uint32_t _binary_fpshader_fpo_start;
extern uint32_t _binary_fpshader_fpo_end;

static unsigned char *vertex_program_ptr = 
(unsigned char *)&_binary_vpshader_vpo_start;
static unsigned char *fragment_program_ptr = 
(unsigned char *)&_binary_fpshader_fpo_start;

static CGprogram vertex_program;
static CGprogram fragment_program;
static CGparameter model_view_projection;
static CGparameter diffuse_bias;

static void *vertex_program_ucode;
static void *fragment_program_ucode;
static uint32_t fragment_offset;
static uint32_t vertex_offset[3];
static uint32_t texcoord_index ;
static uint32_t color_index ;
static uint32_t position_index ;
static uint32_t texture_index;
static float MVP[16];
static float VP[16];

static uint32_t frame_index = 0;

static void setRenderTarget(const uint32_t Index)
{
	CellGcmSurface sf;
	sf.colorFormat 	= CELL_GCM_SURFACE_A8R8G8B8;
	sf.colorTarget	= CELL_GCM_SURFACE_TARGET_0;
	sf.colorLocation[0]	= CELL_GCM_LOCATION_LOCAL;
	sf.colorOffset[0] 	= color_offset[Index];
	sf.colorPitch[0] 	= color_pitch;

	sf.colorLocation[1]	= CELL_GCM_LOCATION_LOCAL;
	sf.colorLocation[2]	= CELL_GCM_LOCATION_LOCAL;
	sf.colorLocation[3]	= CELL_GCM_LOCATION_LOCAL;
	sf.colorOffset[1] 	= 0;
	sf.colorOffset[2] 	= 0;
	sf.colorOffset[3] 	= 0;
	sf.colorPitch[1]	= 64;
	sf.colorPitch[2]	= 64;
	sf.colorPitch[3]	= 64;

	sf.depthFormat 	= CELL_GCM_SURFACE_Z24S8;
	sf.depthLocation	= CELL_GCM_LOCATION_LOCAL;
	sf.depthOffset	= depth_offset;
	sf.depthPitch 	= depth_pitch;

	sf.type		= CELL_GCM_SURFACE_PITCH;
	sf.antialias	= CELL_GCM_SURFACE_CENTER_1;

	sf.width 		= display_width;
	sf.height 		= display_height;
	sf.x 		= 0;
	sf.y 		= 0;
	cellGcmSetSurface(&sf);
}

/* wait until flip */
static void waitFlip(void)
{
	while (cellGcmGetFlipStatus()!=0){
		sys_timer_usleep(300);
	}
	cellGcmResetFlipStatus();
}


static void flip(void)
{
	static int first=1;

	// wait until the previous flip executed
	if (first!=1) 
		waitFlip();
	else 
		cellGcmResetFlipStatus();

	if(cellGcmSetFlip(frame_index) != CELL_OK)
		return;
	
	cellGcmFlush();

	// resend status
	setDrawEnv();
	setRenderState();

	cellGcmSetWaitFlip();

	// New render target
	frame_index = (frame_index+1)%COLOR_BUFFER_NUM;
	setRenderTarget(frame_index);

	first=0;
}


static void initShader(void)
{
	vertex_program   = (CGprogram)vertex_program_ptr;
	fragment_program = (CGprogram)fragment_program_ptr;

	// init
	cellGcmCgInitProgram(vertex_program);
	cellGcmCgInitProgram(fragment_program);

	uint32_t ucode_size;
	void *ucode;
	cellGcmCgGetUCode(fragment_program, &ucode, &ucode_size);
	// 64B alignment required 
	void *ret = localMemoryAlign(64, ucode_size);
	fragment_program_ucode = ret;
	memcpy(fragment_program_ucode, ucode, ucode_size); 

	cellGcmCgGetUCode(vertex_program, &ucode, &ucode_size);
	vertex_program_ucode = ucode;
}

static void buildProjection(float *M, 
		const float top, 
		const float bottom, 
		const float left, 
		const float right, 
		const float near, 
		const float far)
{
	memset(M, 0, 16*sizeof(float)); 

	M[0*4+0] = (2.0f*near) / (right - left);
	M[1*4+1] = (2.0f*near) / (bottom - top);

	float A = (right + left) / (right - left);
	float B = (top + bottom) / (top - bottom);
	float C = -(far + near) / (far - near);
	float D = -(2.0f*far*near) / (far - near);

	M[0*4 + 2] = A;
	M[1*4 + 2] = B;
	M[2*4 + 2] = C;
	M[3*4 + 2] = -1.0f; 
	M[2*4 + 3] = D;
}

static void matrixMul(float *Dest, float *A, float *B)
{
	for (int i=0; i < 4; i++) {
		for (int j=0; j < 4; j++) {
			Dest[i*4+j] 
				= A[i*4+0]*B[0*4+j] 
				+ A[i*4+1]*B[1*4+j] 
				+ A[i*4+2]*B[2*4+j] 
				+ A[i*4+3]*B[3*4+j];
		}
	}
}

static void matrixTranslate(float *M, 
		const float x, 
		const float y, 
		const float z)
{
	memset(M, 0, sizeof(float)*16);
	M[0*4+3] = x;
	M[1*4+3] = y;
	M[2*4+3] = z;

	M[0*4+0] = 1.0f;
	M[1*4+1] = 1.0f;
	M[2*4+2] = 1.0f;
	M[3*4+3] = 1.0f;
}

static void unitMatrix(float *M)
{
	M[0*4+0] = 1.0f;
	M[0*4+1] = 0.0f;
	M[0*4+2] = 0.0f;
	M[0*4+3] = 0.0f;

	M[1*4+0] = 0.0f;
	M[1*4+1] = 1.0f;
	M[1*4+2] = 0.0f;
	M[1*4+3] = 0.0f;

	M[2*4+0] = 0.0f;
	M[2*4+1] = 0.0f;
	M[2*4+2] = 1.0f;
	M[2*4+3] = 0.0f;

	M[3*4+0] = 0.0f;
	M[3*4+1] = 0.0f;
	M[3*4+2] = 0.0f;
	M[3*4+3] = 1.0f;
}

static int32_t initDisplay(void)
{
	uint32_t color_depth=4; // ARGB8
	uint32_t z_depth=4;     // COMPONENT24
	void *color_base_addr;
	void *depth_base_addr;
	void *color_addr[COLOR_BUFFER_NUM];
	void *depth_addr;
	CellVideoOutResolution resolution;

	// display initialize

	// read the current video status
	// INITIAL DISPLAY MODE HAS TO BE SET BY RUNNING SETMONITOR.SELF
	CellVideoOutState videoState;
	cellVideoOutGetState(CELL_VIDEO_OUT_PRIMARY, 0, &videoState);
	cellVideoOutGetResolution(videoState.displayMode.resolutionId, &resolution);

	display_width = resolution.width;
	display_height = resolution.height;
	color_pitch = display_width*color_depth;
	depth_pitch = display_width*z_depth;

	uint32_t color_size =   color_pitch*display_height;
	uint32_t depth_size =  depth_pitch*display_height;

	CellVideoOutConfiguration videocfg;
	memset(&videocfg, 0, sizeof(CellVideoOutConfiguration));
	videocfg.resolutionId = videoState.displayMode.resolutionId;
	videocfg.format = CELL_VIDEO_OUT_BUFFER_COLOR_FORMAT_X8R8G8B8;
	videocfg.pitch = color_pitch;

	// set video out configuration with waitForEvent set to 0 (4th parameter)
	cellVideoOutConfigure(CELL_VIDEO_OUT_PRIMARY, &videocfg, NULL, 0);
	cellVideoOutGetState(CELL_VIDEO_OUT_PRIMARY, 0, &videoState);

	switch (videoState.displayMode.aspect){
	  case CELL_VIDEO_OUT_ASPECT_4_3:
		  display_aspect_ratio=4.0f/3.0f;
		  break;
	  case CELL_VIDEO_OUT_ASPECT_16_9:
		  display_aspect_ratio=16.0f/9.0f;
		  break;
	  default:
		  printf("unknown aspect ratio %x\n", videoState.displayMode.aspect);
		  display_aspect_ratio=16.0f/9.0f;
	}

	cellGcmSetFlipMode(CELL_GCM_DISPLAY_VSYNC);

	// get config
	CellGcmConfig config;
	cellGcmGetConfiguration(&config);
	// buffer memory allocation
	local_mem_heap = (uint32_t)config.localAddress;

	color_base_addr = localMemoryAlign(64, COLOR_BUFFER_NUM*color_size);

	for (int i = 0; i < COLOR_BUFFER_NUM; i++) {
	    color_addr[i]= (void *)((uint32_t)color_base_addr+ (i*color_size));
	    cellGcmAddressToOffset(color_addr[i], &color_offset[i]);
	}

	// regist surface
	for (int i = 0; i < COLOR_BUFFER_NUM; i++) {
		cellGcmSetDisplayBuffer(i, color_offset[i], color_pitch, display_width, display_height);
	}

	depth_base_addr = localMemoryAlign(64, depth_size);
	depth_addr = depth_base_addr;
	cellGcmAddressToOffset(depth_addr, &depth_offset);

	return 0;
}

static void setDrawEnv(void)
{
	cellGcmSetColorMask(CELL_GCM_COLOR_MASK_B|
			CELL_GCM_COLOR_MASK_G|
			CELL_GCM_COLOR_MASK_R|
			CELL_GCM_COLOR_MASK_A);

	cellGcmSetColorMaskMrt(0);
	uint16_t x,y,w,h;
	float min, max;
	float scale[4],offset[4];

	x = 0;
	y = 0;
	w = display_width;
	h = display_height;
	min = 0.0f;
	max = 1.0f;
	scale[0] = w * 0.5f;
	scale[1] = h * 0.5f;
	scale[2] = (max - min) * 0.5f;
	scale[3] = 0.0f;
	offset[0] = x + scale[0];
	offset[1] = y + scale[1];
	offset[2] = (max + min) * 0.5f;
	offset[3] = 0.0f;

	cellGcmSetViewport(x, y, w, h, min, max, scale, offset);
	cellGcmSetClearColor((64<<0)|(64<<8)|(64<<16)|(64<<24));

	cellGcmSetDepthTestEnable(CELL_GCM_FALSE);
	cellGcmSetDepthFunc(CELL_GCM_LESS);

	cellGcmSetBlendEnable(CELL_GCM_TRUE);
	cellGcmSetBlendEquation(CELL_GCM_FUNC_ADD, CELL_GCM_FUNC_ADD);
	cellGcmSetBlendFunc(CELL_GCM_SRC_ALPHA, CELL_GCM_ONE_MINUS_SRC_ALPHA, CELL_GCM_ONE, CELL_GCM_ONE_MINUS_SRC_ALPHA);
}

static void setRenderState(void)
{
	cellGcmSetVertexProgram(vertex_program, vertex_program_ucode);
	cellGcmSetVertexProgramParameter(model_view_projection, MVP);
	
	cellGcmSetVertexDataArray(position_index,
			0, 
			sizeof(Otter::GUIVertex), 
			4, 
			CELL_GCM_VERTEX_F, 
			CELL_GCM_LOCATION_LOCAL, 
			(uint32_t)vertex_offset[0]);
			
	cellGcmSetVertexDataArray(texcoord_index,
			0, 
			sizeof(Otter::GUIVertex), 
			2, 
			CELL_GCM_VERTEX_F, 
			CELL_GCM_LOCATION_LOCAL, 
			(uint32_t)vertex_offset[1]);
			
	cellGcmSetVertexDataArray(color_index,
			0, 
			sizeof(Otter::GUIVertex), 
			4, 
			CELL_GCM_VERTEX_UB, 
			CELL_GCM_LOCATION_LOCAL, 
			(uint32_t)vertex_offset[2]);

	cellGcmSetFragmentProgram(fragment_program, fragment_offset);
}

static int32_t setRenderObject(void)
{
	void *ret = localMemoryAlign(BASED_ALIGN, sizeof(Otter::GUIVertex) * NUM_VERTS);
	vertex_buffer = (Otter::GUIVertex*)ret;

	model_view_projection = cellGcmCgGetNamedParameter(vertex_program, "modelViewProj");
	CGparameter position = cellGcmCgGetNamedParameter(vertex_program, "position");
	CGparameter color = cellGcmCgGetNamedParameter(vertex_program, "color");
	CGparameter texcoord = cellGcmCgGetNamedParameter(vertex_program, "texcoord");
	CGparameter texture = cellGcmCgGetNamedParameter(fragment_program, "texture");
	diffuse_bias = cellGcmCgGetNamedParameter(fragment_program, "diffuse_bias");

	// get Vertex Attribute index
	position_index = cellGcmCgGetParameterResource(vertex_program, position) - CG_ATTR0;
	texcoord_index = cellGcmCgGetParameterResource(vertex_program, texcoord) - CG_ATTR0;
	color_index = cellGcmCgGetParameterResource(vertex_program, color) - CG_ATTR0;
	
	// get Texture Attribute index
	texture_index = cellGcmCgGetParameterResource(fragment_program, texture) - CG_TEXUNIT0;

	// fragment program offset
	cellGcmAddressToOffset(fragment_program_ucode, &fragment_offset);
	cellGcmAddressToOffset(&vertex_buffer->mPosition.x, &vertex_offset[0]);
	cellGcmAddressToOffset(&vertex_buffer->mTexCoord.x, &vertex_offset[1]);
	cellGcmAddressToOffset(&vertex_buffer->mColor, &vertex_offset[2]);
	
	return 0;
}

/* Constructor
 */
PS3Renderer::PS3Renderer(int width, int height)
{	
	memset(mTextures, 0x00, sizeof(mTextures));
	
	mWidth = width;
	mHeight = height;
	
	initDisplay();	
	
	initShader();

	setDrawEnv();

	setRenderObject();

	setRenderState();

	// 1st time
	setRenderTarget(frame_index);
}

/* Virtual Destructor
 */
PS3Renderer::~PS3Renderer(void)
{
}

/* Sets the screen width/height
 */
void PS3Renderer::SetResolution(int width, int height)
{
	mWidth = width;
	mHeight = height;
}

/* Retrieves the display aspect ratio
 */
float PS3Renderer::GetDisplayAspectRatio()
{
	return display_aspect_ratio;
}

#include <cell/cell_fs.h>
#include <sys/paths.h>

#ifdef USE_CFS
#define MOUNT_POINT SYS_DEV_HDD0"/game"
#endif
#ifdef USE_FAT
#define MOUNT_POINT SYS_DEV_MS
#endif
#ifdef USE_HOSTFS_HOME
#define MOUNT_POINT SYS_APP_HOME
#endif
#ifdef USE_HOSTFS_ROOT
#define MOUNT_POINT SYS_HOST_ROOT"/tmp"
#endif
#ifdef USE_DISCFS
#define MOUNT_POINT SYS_DEV_BDVD"/PS3_GAME/USRDIR"
#endif
#ifndef MOUNT_POINT
#define MOUNT_POINT SYS_APP_HOME
#endif

///////////////////////////

/* Loads a texture with the specified id and path
 */
void PS3Renderer::OnLoadTexture(uint32 textureID, const char* szPath)
{	
	for(int i = 0; i < MAX_TEXTURES; i++)
	{
		if(mTextures[i].mTextureID == textureID)
			return;
	}
	
	char fullPath[256];
	sprintf(fullPath, "%s/%s", MOUNT_POINT, szPath);
	
	uint8_t* textureData = NULL;
	uint16_t width = 0;
	uint16_t height = 0;
	uint16_t pixelbyte = 0;

	CellGcmTexture* pTexture = new CellGcmTexture();
	
	if(!decodePng(fullPath, *pTexture))
	{
		delete pTexture;
		return;
	}

	for(int i = 0; i < MAX_TEXTURES; i++)
	{
		if(mTextures[i].mTextureID == 0)
		{
			mTextures[i].mTextureID = textureID;
			mTextures[i].mTexture = pTexture;
			break;
		}
	}
}

/* Unloads a texture with the specified id
 */
void PS3Renderer::OnUnloadTexture(uint32 textureID)
{
	// TODO - UNLOAD RESOURCES, EX ARRAY THAT WAS ALLOCATED IN OnLoadTexture
}

/* Called when a drawing pass has begun
 */
void PS3Renderer::OnDrawBegin()
{
	// clear frame buffer
	cellGcmSetClearSurface(CELL_GCM_CLEAR_Z|
			CELL_GCM_CLEAR_R|
			CELL_GCM_CLEAR_G|
			CELL_GCM_CLEAR_B|
			CELL_GCM_CLEAR_A);
			
			
	// transform
	float M[16];
	float P[16];
	float V[16];	
	
	static float t = -mHeight;
	static float b = 0.0f;
	static float l = 0.0f;
	static float r = mWidth;
	
	// projection 
	buildProjection(P, t, b, l, r, 1.0f, 1000.0f); 

	// 16:9 scale or 4:3 scale
	matrixTranslate(V, 0.0f, 0.0f, -1.0f);
	V[1*4 + 1] = 1.0f;

	// model view 
	matrixMul(VP, P, V);

	unitMatrix(M);
	matrixMul(MVP, VP, M);
	
	setRenderState();
}

/* Called when a drawing pass has ended
 */
void PS3Renderer::OnDrawEnd()
{	
	// start reading the command buffer
	flip();
}

/* Commits a vertex buffer for rendering
 */
void PS3Renderer::OnCommitVertexBuffer(const Otter::GUIVertex* pVertices, uint32 numVertices)
{
	memcpy(vertex_buffer, pVertices, numVertices * sizeof(Otter::GUIVertex));
}

/* Draws primitives on screen
 */
void PS3Renderer::OnDrawBatch(const Otter::DrawBatch& batch)
{	
	uint32 primType = CELL_GCM_PRIMITIVE_TRIANGLES;
	uint32 numVerts = batch.mPrimitiveCount * 3;
	switch(batch.mPrimitiveType)
	{
		case Otter::kPrim_TriangleFan:
		{
			primType = CELL_GCM_PRIMITIVE_TRIANGLE_FAN;
			numVerts -= 2;
			break;
		}
		case Otter::kPrim_TriangleStrip:
		{
			primType = CELL_GCM_PRIMITIVE_TRIANGLE_STRIP;
			numVerts -= 2;
			break;
		}
	}
	
	matrixMul(MVP, VP, (float*)batch.mTransform.mEntry);
	
	CellGcmTexture* pTexture = NULL;
	for(int i = 0; i < MAX_TEXTURES; i++)
	{
		if(mTextures[i].mTextureID == batch.mTextureID)
		{
			pTexture = mTextures[i].mTexture;
			break;
		}
	}

	static float fDiffuseBias = 0.0f;
	
	if(pTexture)
	{
		cellGcmSetTexture(texture_index, pTexture);
		cellGcmSetTextureControl(texture_index, CELL_GCM_TRUE, 0<<8, 12<<8, CELL_GCM_TEXTURE_MAX_ANISO_1);
		cellGcmSetTextureAddress(texture_index,
								 CELL_GCM_TEXTURE_CLAMP,
								 CELL_GCM_TEXTURE_CLAMP,
								 CELL_GCM_TEXTURE_CLAMP,
								 CELL_GCM_TEXTURE_UNSIGNED_REMAP_NORMAL,
								 CELL_GCM_TEXTURE_ZFUNC_LESS, 0);
		cellGcmSetTextureFilter(texture_index, 0,
								CELL_GCM_TEXTURE_LINEAR,
								CELL_GCM_TEXTURE_LINEAR, CELL_GCM_TEXTURE_CONVOLUTION_QUINCUNX);

		fDiffuseBias = 0.0f;
	}
	else
	{
		fDiffuseBias = 1.0f;
	}

	cellGcmSetFragmentProgramParameter(fragment_program, diffuse_bias, &fDiffuseBias, fragment_offset);
	cellGcmSetUpdateFragmentProgramParameter(fragment_offset);

	cellGcmSetVertexProgramParameter(model_view_projection, MVP);
	cellGcmSetDrawArrays(primType, batch.mVertexStartIndex, numVerts);
}

/*E Set the malloc callback function. */
static void *pngDecCbControlMalloc(uint32_t size, void *cbCtrlMallocArg){
	(void)cbCtrlMallocArg;
	return malloc(size);
}

/*E Set the free callback function. */
static int32_t pngDecCbControlFree(void *ptr, void *cbCtrlFreeArg){
	(void)cbCtrlFreeArg;
	free(ptr);
	return 0;
}

bool decodePng(const char* szPath, CellGcmTexture& tex)
{
	if(!szPath)
		return false;

	int ret;
	bool bLoaded = false;

	CellPngDecMainHandle        mainHandle;
	CellPngDecSubHandle         subHandle;
	
	// texture setup

	ret = cellSysmoduleLoadModule(CELL_SYSMODULE_PNGDEC);
	if(ret != CELL_OK)
	{
		printf("failed:cellSysmoduleLoadModule(CELL_SYSMODULE_PNGDEC) return 0x%X\n", ret);
		return false;
	}

	{
		CellPngDecThreadInParam 	threadInParam;
		CellPngDecThreadOutParam 	threadOutParam;

		threadInParam.spuThreadEnable   = CELL_PNGDEC_SPU_THREAD_DISABLE;
		threadInParam.ppuThreadPriority = 512;
		threadInParam.spuThreadPriority = 200;
		threadInParam.cbCtrlMallocFunc  = pngDecCbControlMalloc;
		threadInParam.cbCtrlMallocArg   = NULL;
		threadInParam.cbCtrlFreeFunc    = pngDecCbControlFree;
		threadInParam.cbCtrlFreeArg     = NULL;

		ret = cellPngDecCreate(&mainHandle, &threadInParam, &threadOutParam);
		if (ret < 0) 
{
			printf("cellPngDecCreate() failed (%x)\n", ret);
			cellSysmoduleUnloadModule(CELL_SYSMODULE_PNGDEC);
			return false;
		}
	}

	{
		CellPngDecSrc 		        src; 
		CellPngDecOpnInfo 	        openInfo;

		/*E Set the stream source. */
		src.srcSelect     = CELL_PNGDEC_FILE;
		src.fileName      = szPath;
		src.fileOffset    = 0;		
		src.fileSize      = 0;
		src.streamPtr     = NULL;
		src.streamSize    = 0;

		/*E Set the spu thread disable/enable. */
		src.spuThreadEnable  = CELL_PNGDEC_SPU_THREAD_DISABLE;

		ret = cellPngDecOpen(mainHandle, &subHandle, &src, &openInfo);
		if (ret < 0) 
		{
			printf("cellPngDecOpen() returned = 0x%x\n", ret);
			cellPngDecDestroy(mainHandle);
			return false;
		}
	}

	{
		CellPngDecInfo 		        info;
		CellPngDecInParam 	        inParam;
		CellPngDecOutParam 	        outParam;

		CellPngDecDataOutInfo 	    dataOutInfo;
		CellPngDecDataCtrlParam     dataCtrlParam;

		/*E Read the png header by PNG Decoder. */
		ret = cellPngDecReadHeader(mainHandle, subHandle, &info);
		if (ret < 0) 
		{
			printf("cellPngReadHeader() returned 0x%x\n", ret);
		}

		/*E Set the parameter for PNG Decoder. */
		inParam.commandPtr        = NULL;
		inParam.outputMode        = CELL_PNGDEC_TOP_TO_BOTTOM;
		//inParam.outputColorSpace  = CELL_PNGDEC_RGBA;
		inParam.outputColorSpace  = CELL_PNGDEC_ARGB;
		//inParam.outputColorSpace = CELL_PNGDEC_GRAYSCALE_ALPHA;
		inParam.outputBitDepth    = 8;
		inParam.outputPackFlag    = CELL_PNGDEC_1BYTE_PER_1PIXEL;

		if((info.colorSpace == CELL_PNGDEC_GRAYSCALE_ALPHA)
		   ||(info.colorSpace == CELL_PNGDEC_RGBA)
		   ||(info.chunkInformation & 0x10))
		{
			inParam.outputAlphaSelect = CELL_PNGDEC_STREAM_ALPHA;
		}
		else
		{
			inParam.outputAlphaSelect = CELL_PNGDEC_FIX_ALPHA;
		}

		inParam.outputColorAlpha  = 0xff;

		ret = cellPngDecSetParameter(mainHandle, subHandle, &inParam, &outParam);
		if (ret < 0) 
		{
			printf("cellPngDecSetParameter() returned 0x%x\n", ret);
			goto end;
		}

		/*E Set the output area */
		//dataCtrlParam.outputBytesPerLine = outParam.outputWidthByte * outParam.outputComponents;
		dataCtrlParam.outputBytesPerLine = outParam.outputWidth * outParam.outputComponents;

		//m_tex_addr = (void*)SNaviLocalMemory::Allocate(outParam.useMemorySpace, 128);
		void* textureData = localMemoryAlign(BASED_ALIGN, outParam.outputWidth * outParam.outputHeight * outParam.outputComponents);
		if(!textureData)
		{
			fprintf(stderr, "Out Of Memory.\n");
			goto end;
		}

		memset(textureData, 0x00, outParam.useMemorySpace);

		/*E Decode PNG */
		ret = cellPngDecDecodeData(mainHandle, subHandle, (uint8_t*)textureData, &dataCtrlParam, &dataOutInfo);
		if (ret < 0) {
			printf("cellPngDecDecodeData() returned 0x%x\n", ret);
			goto end;
		}

		cellGcmAddressToOffset(textureData, &(tex.offset));
	
		// bind texture
		tex.format = CELL_GCM_TEXTURE_A8R8G8B8 | CELL_GCM_TEXTURE_LN;
		tex.remap = 	CELL_GCM_TEXTURE_REMAP_REMAP << 14 |
			CELL_GCM_TEXTURE_REMAP_REMAP << 12 |
			CELL_GCM_TEXTURE_REMAP_REMAP << 10 |
			CELL_GCM_TEXTURE_REMAP_REMAP <<  8 |
			CELL_GCM_TEXTURE_REMAP_FROM_B << 6 |
			CELL_GCM_TEXTURE_REMAP_FROM_G << 4 |
			CELL_GCM_TEXTURE_REMAP_FROM_R << 2 |
			CELL_GCM_TEXTURE_REMAP_FROM_A;
		
		tex.mipmap = 1;
		tex.dimension = CELL_GCM_TEXTURE_DIMENSION_2;
		tex.cubemap = CELL_GCM_FALSE;
		tex.width = outParam.outputWidth;
		tex.height = outParam.outputHeight;
		tex.depth = 1;
		tex.pitch = outParam.outputWidth * outParam.outputComponents;
		tex.location = CELL_GCM_LOCATION_LOCAL;

		bLoaded = true;
	}

end:
	cellPngDecClose(mainHandle, subHandle);
	cellPngDecDestroy(mainHandle);
	cellSysmoduleUnloadModule(CELL_SYSMODULE_PNGDEC);

	return bLoaded;
}
