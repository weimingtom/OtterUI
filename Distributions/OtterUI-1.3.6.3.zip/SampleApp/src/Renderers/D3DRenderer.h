//
// Copyright (c) Lloyd Tullues
// All rights reserved.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND 
// CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, 
// INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, 
// OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
// OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
// OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#pragma once

#include <map>
#include <vector>
#include <d3dx9.h>
#include "SampleRenderer.h"

/* Direct3D Renderer implementation
 */
class D3DRenderer : public SampleRenderer
{
public:
	/* Constructor
	*/
	D3DRenderer(HWND hWnd, int width, int height, bool fullscreen);

	/* Virtual Destructor
	*/
	virtual ~D3DRenderer(void);

public:

	/* Loads a texture with the specified id and path
	 */
	virtual void OnLoadTexture(int textureID, const char* szPath);

	/* Unloads a texture with the specified id
	 */
	virtual void OnUnloadTexture(int textureID);

	/* Called when a drawing pass has begun
	 */
	virtual void OnDrawBegin();

	/* Called when a drawing pass has ended
	 */
	virtual void OnDrawEnd();

	/* Commits a vertex buffer for rendering
	 */
	virtual void OnCommitVertexBuffer(const Otter::GUIVertex* pVertices, uint32 numVertices);

	/* Draws primitives on screen
	 */
	virtual void OnDrawBatch(const Otter::DrawBatch& batch);
	
	/**
	 * Sets the renderer to draw to the stencil buffer
	 */
	virtual void SetStencilState(StencilState state);

private:
	
	/* Creates the necessary D3D objects
	 */
	void InitD3D(HWND hWnd);

	/* Retrieves the D3D Present Parameters
	 */
	void GetPresentParams(D3DPRESENT_PARAMETERS &d3dpp);

	/* Creates the index / vertex buffers
	 */
	void CreateBuffers();

	/* Creates the shaders
	 */
	void CreateShaders();

private:
	
	LPDIRECT3D9							mD3D;
	LPDIRECT3DDEVICE9					mD3DDevice;
	D3DPRESENT_PARAMETERS				mD3DPresentParams;	

	LPD3DXEFFECT						mEffect;
	LPDIRECT3DVERTEXBUFFER9 			mVertexBuffer;
	LPDIRECT3DVERTEXDECLARATION9		mVertexDeclaration;

	bool								mFullscreen;

	std::map<int, LPDIRECT3DTEXTURE9>	mTextures;

	D3DXMATRIX							mModel;
	D3DXMATRIX							mView;
	D3DXMATRIX							mProjection;
};
