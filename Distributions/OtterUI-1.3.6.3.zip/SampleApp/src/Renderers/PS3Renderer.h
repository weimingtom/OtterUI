#pragma once

#include <map>
#include "Otter.h"
#include "SampleRenderer.h"

/* Crude texture map
 */
class CellGcmTexture;
struct TextureMap
{
	int mTextureID;
	CellGcmTexture* mTexture;
};

#define MAX_TEXTURES 100

/* OpenGL ES Renderer implementation
 */
class PS3Renderer : public SampleRenderer
{
public:
	/* Constructor
	 */
	PS3Renderer(int width, int height);
	
	/* Virtual Destructor
	 */
	virtual ~PS3Renderer(void);
	
public:
	
	/* Sets the screen resolution.
	 * width/height indicates the size of the ortho projection.
	 */
	void SetResolution(int width, int height);
	
public:
	
	/* Loads a texture with the specified id and path
	 */
	virtual void OnLoadTexture(uint32 textureID, const char* szPath);
	
	/* Unloads a texture with the specified id
	 */
	virtual void OnUnloadTexture(uint32 textureID);
	
	/* Called when a drawing pass has begun
	 */
	virtual void OnDrawBegin();
	
	/* Called when a drawing pass has ended
	 */
	virtual void OnDrawEnd();
	
	/* Commits a vertex buffer for rendering
	 */
	virtual void OnCommitVertexBuffer(const Otter::GUIVertex* pVertices, uint32 numVertices);
	
	/* Draws primitives on screen
	 */
	virtual void OnDrawBatch(const Otter::DrawBatch& batch);
	
public:

	/* Retrieves the display aspect ratio
	 */
	float GetDisplayAspectRatio();

private:

	TextureMap	mTextures[MAX_TEXTURES];
};
