//
// Copyright (c) Lloyd Tullues
// All rights reserved.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND 
// CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, 
// INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, 
// OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
// OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
// OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#pragma once
#include <string>
#include <vector>
#include "Otter.h"

using namespace Otter;

class IntroHandler;
class ViewHandler;
class SamplePlugin;

/* Handles all GUI System Events
 */
class SampleUI
{
public:

	/* Constructor
	 */
	SampleUI(IRenderer* pRenderer, ISoundSystem* pSoundSystem, IFileSystem* pFileSystem);

	/* Destructor
	 */
	~SampleUI();

public:
	/* Queues the current scene to be unloaded and the specified one to be loaded in its
	 * place.
	 */
	void SwitchToScene(const char* szScene, const char* szInitialView);

	/* Called when a new scene has been loaded
	 */
	void OnSceneLoaded(void* pSystem, Scene* pScene);

	/* Called when a scene has been unloaded
	 */
	void OnSceneUnloaded(void* pSystem, Scene* pScene);

	/* Retrieves the Otter System object
	 */
	Otter::System* GetSystem() { return mSystem; }

public:

	/* Updates the Sample UI
	 */
	void Update(float delta);

	/* Draws the Sample UI
	 */
	void Draw();

private:

	Otter::System*			mSystem;

	std::string				mNextScene;
	std::string				mInitialView;

	std::vector<ViewHandler*> mViews;

	SamplePlugin*			mSamplePlugin;
};
