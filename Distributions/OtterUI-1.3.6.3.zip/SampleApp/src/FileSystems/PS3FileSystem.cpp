//
// Copyright (c) Aonyx Software, LLC
// All rights reserved.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND 
// CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, 
// INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, 
// OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
// OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
// OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#include <stdio.h>
#include <string.h>

#include <sys/process.h>
#include <sys/paths.h>
#include <sys/timer.h>
#include <cell/cell_fs.h>
#include <cell/sysmodule.h>

#include "PS3FileSystem.h"

#ifdef USE_CFS
#define MOUNT_POINT SYS_DEV_HDD0"/game"
#endif
#ifdef USE_FAT
#define MOUNT_POINT SYS_DEV_MS
#endif
#ifdef USE_HOSTFS_HOME
#define MOUNT_POINT SYS_APP_HOME
#endif
#ifdef USE_HOSTFS_ROOT
#define MOUNT_POINT SYS_HOST_ROOT"/tmp"
#endif
#ifdef USE_DISCFS
#define MOUNT_POINT SYS_DEV_BDVD"/PS3_GAME/USRDIR"
#endif
#ifndef MOUNT_POINT
#define MOUNT_POINT SYS_APP_HOME
#endif

static int isMounted(const char *path)
{
    int i, err;
    CellFsStat status;

    printf("Waiting for mounting\n");
    for (i = 0; i < 15; i++) {
        err = cellFsStat(path, &status);
        if (err == CELL_FS_SUCCEEDED) {
            printf("Waiting for mounting done\n");
            return 1;
        }
		
        sys_timer_sleep(1);
        printf(".\n");
    }
    printf("Waiting for mounting failed\n");
    return 0;
}


/**
 * Opens a file according to the read/write flags.
 */
PS3FileSystem::PS3FileSystem(void)
{	
	mReady = false;

	int ret;
    ret = cellSysmoduleLoadModule(CELL_SYSMODULE_FS);
    if (ret) 
	{
		return;
    }

    if (!isMounted(MOUNT_POINT)) 
	{
		return;
    }
	
	mReady = true;
}

/**
 * Closes the file when the VirtualFile is destroyed.
 */
PS3FileSystem::~PS3FileSystem(void)
{
}

/* @brief Opens a file
 */
void* PS3FileSystem::Open(const char* szFilename, Otter::AccessFlag flags)
{
	int fd = 0;
    char fullPath[256];
	sprintf(fullPath, "%s/%s", MOUNT_POINT, szFilename);
	
    cellFsOpen(fullPath, CELL_FS_O_RDWR | CELL_FS_O_CREAT, &fd, NULL, 0);
	
	return (void*)fd;
}

/* @brief Closes the file
 */
void PS3FileSystem::Close(void* pHandle)
{
	if(!pHandle)
		return;
		
	cellFsClose((int)pHandle);
}

/* @brief Reads data from the file.
 */
uint32 PS3FileSystem::Read(void* pHandle, uint8* data, uint32 count)
{
	if(!pHandle)
		return 0;
	
	uint64 sr;
	cellFsRead((int)pHandle, (void *)data, (uint64)count, &sr);
	
	return (uint32)sr;
}

/* @brief Writes data to the file.
 */
uint32 PS3FileSystem::Write(void* pHandle, uint8* data, uint32 count)
{
	if(!pHandle)
		return 0;
	
	uint64 sw;
	cellFsRead((int)pHandle, (void *)data, (uint64)count, &sw);
	
	return (uint32)sw;
}

/* @brief Seeks within the file.
 */
void PS3FileSystem::Seek(void* pHandle, uint32 offset, Otter::SeekFlag seekFlag)
{
	if(!pHandle)
		return;
		
	uint32 flag = CELL_FS_SEEK_SET;
	
	if(seekFlag & Otter::kCurrent)
	{
		flag = CELL_FS_SEEK_CUR;
	}
	
	if(seekFlag & Otter::kEnd)
	{
		flag = CELL_FS_SEEK_END;
	}
	
	uint64 offset64 = offset;
    cellFsLseek((int)pHandle, 0, flag, &offset64);
}

/* @brief Returns the size of the file
 */
uint32 PS3FileSystem::Size(void* pHandle)
{	
	if(!pHandle)
		return 0;
	
	CellFsStat stat;
	cellFsFstat((int)pHandle, &stat);
	
	return stat.st_size;
}
