//
// Copyright (c) Lloyd Tullues
// All rights reserved.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND 
// CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, 
// INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, 
// OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
// OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
// OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#pragma once
#include "Otter.h"

/* Sample IFileSystem implementation.  Simply opens, reads from, and closes raw files using
 * standard C++ methods.
 */
class SampleFileSystem : public Otter::IFileSystem
{
public:
	SampleFileSystem(void);
	~SampleFileSystem(void);

public:		

	/* @brief Opens a file
	 */
	virtual void* Open(const char* szFilename, Otter::AccessFlag flags);

	/* @brief Closes the file
	 */
	virtual void Close(void* pHandle);

	/* @brief Reads data from the file.
	 */
	virtual uint32 Read(void* pHandle, uint8* data, uint32 count);

	/* @brief Writes data to the file.
	 */
	virtual uint32 Write(void* pHandle, uint8* data, uint32 count);

	/* @brief Seeks within the file.
	 */
	virtual void Seek(void* pHandle, uint32 offset, Otter::SeekFlag seekFlag);

	/* @brief Returns the size of the file
	 */
	virtual uint32 Size(void* pHandle);
};
