#pragma once

#include <map>
#include "Otter.h"

/* Implements the Sound System for PS3.  Makes JNI
 * calls back to the Java layer to load and play sounds.
 */
class PS3SoundSystem : public Otter::ISoundSystem
{
public:
	/* Constructor
	 */
	PS3SoundSystem();

	/*
	 */
	virtual ~PS3SoundSystem(void);

public:

	/* Loads a sound with the specified id and path
	 */
	virtual void OnLoadSound(uint32 soundID, const char* szSoundPath);

	/* Unloads a sound with the specified id
	 */
	virtual void OnUnloadSound(uint32 soundID);

	/* Plays a sound at the specified volume
	 */
	virtual void OnPlaySound(uint32 soundID, float volume);
};

