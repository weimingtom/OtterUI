#include "PS3SoundSystem.h"

/* Constructor
 */
PS3SoundSystem::PS3SoundSystem()
{
}

/* Virtual Destructor
 */
PS3SoundSystem::~PS3SoundSystem(void)
{
}

/* Loads a sound with the specified id and path
 */
void PS3SoundSystem::OnLoadSound(uint32 soundID, const char* szSoundPath)
{
}	

/* Unloads a sound with the specified id
 */
void PS3SoundSystem::OnUnloadSound(uint32 soundID)
{
}

/* Plays a sound at the specified volume
 */
void PS3SoundSystem::OnPlaySound(uint32 soundID, float volume)
{
} 