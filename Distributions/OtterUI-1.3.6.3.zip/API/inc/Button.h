//
// OtterUI v. 1.3.6.3
//
// Copyright (c) Lloyd Tullues
// All rights reserved.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND 
// CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, 
// INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, 
// OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
// OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
// OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#pragma once
#include "Control.h"

#include "Common/UTF8String.h"
#include "Common/Event.h"

namespace Otter
{
	struct ButtonData;
	class View;
	class Label;

	/**
	 * The Button maintains several states, and fires an event
	 * whenever it's been clicked.
	 */
	class Button : public Control
	{
	private:
		enum State
		{
			Default,
			Down
		};

	public:
		/**
		 * Constructs a new button within the specified scene and with the specified parent control.
		 */
		Button(Scene* pScene, Control* pParent, const ButtonData* pButtonData);

		/**
		 * Constructs a new button control at runtime.  The button will not be active until it is added
		 * to an existing control or view as a child control.
		 */
		Button();

		/**
		 * Virtual Destructor
		 */
		virtual ~Button(void);

	public:

		/**
		 * Sets the font by name
		 */
		Result SetFont(const char* szFontName);
		
		/**
		 * Sets the label's text
		 */
		Result SetText(const UTF8String& text);

		/**
		 * Sets the label's text
		 */
		Result SetText(const char* szText);

		/**
		 * Sets the label's color
		 */
		Result SetTextColor(uint32 color);

		/**
		 * Retrieves the label's color
		 */
		uint32 GetTextColor();
		
		/**
		 *  Sets the horizontal and vertical text alignment
		 */
		Result SetTextAlignment(HoriAlignment halign, VertAlignment valign);

		/**
		 * Sets the label's font drawing scale
		 */
		Result SetTextScale(float scaleX, float scaleY);

		/**
		 * Sets the texture to be displayed during the default state
		 */
		Result SetDefaultTexture(const char* szTexture);

		/**
		 * Sets the texture to be displayed during the down state
		 */
		Result SetDownTexture(const char* szTexture);

		/**
		 * Sets the control's size
		 */
		virtual void SetSize(const VectorMath::Vector2& size);

		/**
		 * Sets the control's parent
		 */
		virtual Result SetParentControl(Control* pParent);

	public:
		
		/**
		 * Called whenever this control is activated
		 */
		virtual void OnActivate();

		/**
		 * Called whenever this control is deactivated
		 */
		virtual void OnDeactivate();

	public:
		
		/**
		 * Clones the control and returns the new instance
		 */
		virtual Control* Clone();

		/**
		 * Draws the button to screen
		 */
		virtual void Draw(Graphics* pGraphics);

	private:

		/**
		 * Points (touches/mouse/etc) were pressed down
		 */
		virtual bool OnPointsDown(Point* points, sint32 numPoints);
		
		/**
		 * Points (touches/mouse/etc) were released
		 */
		virtual bool OnPointsUp(Point* points, sint32 numPoints);
		
		/**
		 * Points (touches/mouse/etc) were moved.
		 */
		virtual bool OnPointsMove(Point* points, sint32 numPoints);

	private:

		/** @brief Updates the button's text label
		 */
		void UpdateLabel();
	
	public:	
		
		/**
		 * Raised whenever the button has been clicked.
		 * Event Parameter: Unused
		 */
		Event<void*>	mOnClick;

	private:

		/**
		 * Button's current state
		 */
		State			mButtonState;

		/**
		 * Label to be rendered on top of the button
		 */
		Label*			mLabel;
	};
}