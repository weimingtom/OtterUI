//
// OtterUI v. 1.3.6.3
//
// Copyright (c) Lloyd Tullues
// All rights reserved.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND 
// CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, 
// INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, 
// OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
// OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
// OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#pragma once 

#include "Common/Types.h"
#include "Otter.h"

namespace Otter
{
	/**
	 * Interface for user rendering of the UI
	 */
	class IRenderer
	{
	public:	
		enum StencilState
		{
			DISABLE_STENCIL,
			DRAW_TO_STENCIL,
			DRAW_USING_STENCIL
		};
		
	public:
		/**
		 * Constructor
		 */
		IRenderer(void) { };

		/**
		 * Virtual Destructor
		 */
		virtual ~IRenderer(void) { };

	public:

		/**
		 * Loads a texture with the specified id and path
		 */
		virtual void OnLoadTexture(sint32 /*textureID*/, const char* /*szPath*/) { }

		/**
		 * Unloads a texture with the specified id
		 */
		virtual void OnUnloadTexture(sint32 /*textureID*/) { }

		/**
		 * Called when a drawing pass has begun
		 */
		virtual void OnDrawBegin() { }

		/**
		 * Called when a drawing pass has ended
		 */
		virtual void OnDrawEnd() { }

		/**
		 * Commits a vertex buffer for rendering
		 */
		virtual void OnCommitVertexBuffer(const GUIVertex* /*pVertices*/, uint32 /*numVertices*/) = 0;

		/**
		 * Draws primitives on screen
		 */
		virtual void OnDrawBatch(const DrawBatch& /*batch*/) = 0;

		/**
		 * Sets the renderer to draw to the stencil buffer
		 */
		virtual void SetStencilState(StencilState state) { }
	};
}