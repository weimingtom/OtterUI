//
// OtterUI v. 1.3.6.3
//
// Copyright (c) Lloyd Tullues
// All rights reserved.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND 
// CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, 
// INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, 
// OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
// OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
// OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#pragma once

#include "Common/Types.h"

namespace Otter
{
	enum AccessFlag
	{
		kBinary	 		=	(1 << 0),
		kRead	 		=	(1 << 1),
		kWrite	 		=	(1 << 2),
		kAppend  		=	(1 << 3),
		kTruncate		=	(1 << 4)
	};

	enum SeekFlag
	{
		kBegin			=	(1 << 0),
		kCurrent		=	(1 << 1),
		kEnd			=	(1 << 2)
	};

	/**
	 * Custom File System.  Used to implement own file i/o routines.
	 */
	class IFileSystem
	{
	public:
		/**
		 * Constructor
		 */
		IFileSystem(void) { }

		/**
		 * Virtual Destructor
		 */
		virtual ~IFileSystem(void) { }

	public:		

		/**
		 * Opens a file
		 */
		virtual void* Open(const char* szFilename, AccessFlag flags) = 0;

		/**
		 * Closes the file
		 */
		virtual void Close(void* pHandle) = 0;

		/**
		 * Reads data from the file.
		 */
		virtual uint32 Read(void* pHandle, uint8* data, uint32 count) = 0;

		/**
		 * Writes data to the file.
		 */
		virtual uint32 Write(void* pHandle, uint8* data, uint32 count) = 0;

		/**
		 * Seeks within the file.
		 */
		virtual void Seek(void* pHandle, uint32 offset, SeekFlag seekFlag) = 0;

		/**
		 * Returns the size of the file
		 */
		virtual uint32 Size(void* pHandle) = 0;
	};
}