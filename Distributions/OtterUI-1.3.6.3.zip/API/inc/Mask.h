//
// OtterUI v. 1.3.6.3
//
// Copyright (c) Lloyd Tullues
// All rights reserved.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND 
// CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, 
// INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, 
// OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
// OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
// OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#pragma once
#include "Control.h"

namespace Otter
{
	struct MaskData;
	class View;

	/**
	 * Mask used to mask out parts of other controls
	 */
	class Mask : public Control
	{
	public:
		/**
		 * Constructor
		 */
		Mask(Scene* pScene, Control* pParent, const MaskData* pMaskData);

		/* Constructor
		 */
		Mask();

		/* Destructor
		 */
		virtual ~Mask(void);

	public:

		/**
		 * Sets the texture to be displayed
		 */
		Result SetTexture(const char* szTexture);

		/** 
	     * Sets the UVs for the mask.  Useful to display a section
		 * of the mask texture.  Clamped to [0,0] and [1,1]
		 */
		Result SetUVs(	float u_tl, float v_tl, 
						float u_br, float v_br);

		/**
		 * Sets the mask's skew
		 */
		void SetSkew(float skew);

		/**
		 * Retrieves the mask's skew
		 */
		float GetSkew();

	public:
		
		/**
		 * Clones the control and returns the new instance
		 */
		virtual Control* Clone();

		virtual void Draw(Graphics* pGraphics) {}

		/**
		 * Draws the mask to the stencil buffer
		 */
		virtual void DrawMask(Graphics* pGraphics);

		/**
		 * Applies the interpolation of two keyframes to the control.
		 * pEndFrame can be NULL.
		 */
		virtual void ApplyKeyFrame(const KeyFrameData* pStartFrame, const KeyFrameData* pEndFrame, float factor);

	private:

		float tl_uv[2];
		float br_uv[2];
	};
}